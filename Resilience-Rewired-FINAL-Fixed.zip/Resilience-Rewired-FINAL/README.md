# Resilience Rewired

A working financial resilience engine for the Tangerine track at Sheridan Datathon 2026.

The app accepts any of 4,500 anonymized account IDs, calculates benchmark financial metrics, applies editable shocks, creates grounded emergency fund and contingency plans, and compares account cohorts.

## Run locally

The `dist/` folder contains a static site. Serve it with any local static server, for example:

```bash
python -m http.server 8080 --directory dist
```

Open `http://localhost:8080`.

## Recreate the data

The challenge organizer supplied a ZIP containing nine CSV files and a README. Recreate the compact data assets with:

```bash
python scripts/build_data.py /path/to/challenge.zip
```

The script writes `dist/data/accounts.json` and `dist/data/summary.json` with values based on the provided CSVs. Account history remains in the original challenge data. The source ZIP is not needed to run the published site because the precomputed data assets are included.

## Benchmark calculations

For each account:

* `I` is the median of monthly `money_in`.
* `S` is the median of monthly `money_out`.
* `F` is the median of the monthly sum `household_bills + insurance + loan_payments`.
* `H` is the median of monthly `household_bills`.
* `B` is the mean of `avg_daily_balance` over the last six months.
* `P` is the monthly loan payment when the loan status is C or D, otherwise zero.

Under a shock, `income = I * retained_percentage`, `spending = S + bills_increase * H + additional_monthly_expenses`, and `buffer_left = B - one_time_costs`.

If `buffer_left <= 0`, runway is zero. If shocked spending is no higher than shocked income, show `no shortfall (120+)`. Otherwise, runway is `min(buffer_left / (spending - income), 120)` months rounded to one decimal.

The optional projection of Employment Insurance ending after a chosen number of months is separate from the benchmark runway and does not overwrite the judge-facing formula. In the Shock tab, **How many months to show** controls the chart horizon (1–24 months). **Months of illustrative EI** controls the hypothetical timing of income ending when the separate **Model EI ending** switch is on and income retention is below 100%. The two sliders have different jobs.

## Discovery

Under an illustrative 55% income retention scenario, **285 of 448 accounts with an active loan (63.6%)** fall below six months of runway, compared with **1,293 of 4,052 without an active loan (31.9%)**. This is a correlation in historical transformed data, not causal evidence. Exact values are computed by `scripts/build_data.py` and displayed in the Discoveries section.

## Files in the website

* `dist/index.html`: page structure and wording
* `dist/tangerine.css`: the light Tangerine-inspired design; `dist/styles.css`: original shared styles; `dist/live.css`: styles for the live-data panels
* `dist/app.js`: core functionality and the official benchmark formulas
* `dist/extras.js`: extra interactive features (money calendar, peer comparison, risk ranking, loan checker and more)
* `dist/live.js`: the live-data layer. It asks the server (Tiger Data) for data and falls back to the built-in files
* `dist/data/*.json`: account data, summary and extras. `dist/data/embedded.js` is the same data as one script, used only when `index.html` is opened straight from disk
* After changing any JSON file, regenerate the embedded script with `python scripts/rebuild_embedded.py`

Without the server, double-clicking `dist/index.html` still works with all features, using the built-in files.

The **Data systems** tab explains the Snowflake → Tiger Data → Vultr → domain pipeline. **Check connections** requests the current server health and updates displayed connection status. **Verify this scenario** asks Tiger Data to calculate the active customer's current shock and compares its answer against the browser calculation. Both buttons report clearly when the live server is unavailable, without requiring a cloud connection to use the other features.

## Sponsor technologies

The website works offline from precomputed files, and uses live data from Snowflake and Tiger Data when they're connected:

* **Gemini**: an optional prompt helper remains in the source code, but is not displayed in the current app. No live Gemini API connection is claimed.
* **Snowflake**: the analysis engine. All 9 CSVs are loaded into Snowflake, and `integrations/snowflake/` computes every per-account feature and cross-account finding. The app server talks to it through the Snowflake SQL API. See *Live data* below.
* **Tiger Data**: the serving database. Snowflake's results are stored in Tiger Data (TimescaleDB hypertable for the monthly history), and the app reads one customer at a time from it. The shock formula also runs inside Tiger Data as a SQL function. See *Live data* below.
* **Vultr**: the hosting. The app server (website + API) runs in Docker on a Vultr cloud server behind Caddy for automatic HTTPS. `deploy/vultr/` creates the server and deploys to it. See *Deploy on Vultr* below.
* **Solana**: optional future use for publicly timestamping a hash of a report, never customer records. No chain transaction is currently made.
* **GoDaddy Registry**: the custom domain resiliencerewired.biz (a GoDaddy Registry `.biz`) points at the Vultr server, with HTTPS from Caddy. See *Custom domain* below.
* **Entire**: a possible collaboration workflow for source development; no Entire session is claimed without a configured account.

Integrations require their respective services and credentials. The site shows their real status and never labels them as connected when they are not.

## Live data: Snowflake + Tiger Data

Each service has one job:

```
9 challenge CSVs ──► Snowflake ──(SQL API)──► Tiger Data ──► server/app.py ──► website
                     computes                 stores and       /api/account, /api/findings,
                     features + findings      serves           /api/scenario, /api/refresh
```

* **Snowflake computes.** `integrations/snowflake/02_features.sql` builds `ACCOUNT_FEATURES` (one row per account: the judges' I, S, F, H, B, P plus income source, income group, EI cliff, worst month, warning signs before a loan, committed standing orders). `03_findings.sql` builds `FINDINGS` (income paradox, below-zero before a loan, EI cliff, loan affordability, emergency fund groups).
* **Tiger Data serves.** `integrations/tiger_data/schema.sql` stores the features, the findings and the monthly history (a TimescaleDB hypertable with a yearly `time_bucket` roll-up). The `runway()` and `scenario()` SQL functions run the judges' formula in the database.
* **The website stays fast and safe.** `dist/live.js` uses the API when it answers within 3 seconds, and otherwise falls back to `dist/data/*.json`. If the database drops mid-demo, the next account loads from the built-in files and the header says so.

### Set up (about 20 minutes)

1. **Tiger Data:** create a free service in Tiger Cloud and copy its connection string.
2. **Snowflake:** create a programmatic access token for your user (Snowsight > your profile > Programmatic access tokens). If token creation is refused, your account may need an authentication policy or network policy that allows tokens.
3. Copy `.env.example` to `.env` (Windows: `copy .env.example .env`) and fill it in. The scripts and the server read `.env` automatically, so there is nothing to load.
4. Install: `pip install -r requirements-dev.txt`
5. Load the CSVs into Snowflake and build features + findings:
   `python scripts/snowflake_load.py /path/to/data`
6. Copy Snowflake's results into Tiger Data through the SQL API:
   `python scripts/sync_to_tiger.py --source snowflake`
7. Run the app: `python server/app.py`, then open `http://localhost:8080`. The header should say **Live: Tiger Data · computed in Snowflake**.

To recompute in Snowflake and reload Tiger Data while the app runs:
`curl -X POST -H "X-Admin-Token: $ADMIN_TOKEN" http://localhost:8080/api/refresh`

No Snowflake access yet? `python scripts/sync_to_tiger.py --source local --data /path/to/data` runs the same SQL locally in DuckDB. The app then says "computed locally", never "computed in Snowflake".

### Tests

```bash
python scripts/test_calculations.py                 # published data matches the judges' benchmark
python tests/test_pipeline.py /path/to/data         # Snowflake SQL (run in DuckDB) matches the app for all 4,500 accounts
python tests/test_snowflake_api.py                  # SQL API client: token headers, polling, partitions
python tests/mock_snowflake.py /path/to/data 8099   # stand-in SQL API for end-to-end runs without an account
```

## Accuracy limitations

`money_in` includes transfers and pensions, so it is not confirmed employment salary. A bank account balance is only a proxy for savings. The source data originates from a Czech bank and the original district names are not Canadian locations. The EI scenario is an example, not a personal benefits eligibility decision. The plans are modeled budget scenarios and require verification before real use.

## Credits

PKDD'99 Discovery Challenge Financial dataset, CTU Prague Relational Dataset Repository: https://relational.fel.cvut.cz/dataset/Financial

Tangerine Resilience Rewired challenge instructions, Sheridan Datathon 2026.


## Deploy on Vultr

Vultr hosts the app server, so the site is on a public URL with the Tiger Data and Snowflake connections behind it.

```
browser ──► Caddy (HTTPS, ports 80/443) ──► app container (server/app.py) ──► Tiger Data (Snowflake feeds it)
            all on one Vultr cloud server (Ubuntu 24.04 + Docker)
```

1. **Get an API key.** In my.vultr.com, open Account > API, enable it, and allow your IP. Optionally save your SSH public key under Account > SSH Keys and copy its id.
2. **Create the server** (Toronto, about $5/month):
   ```
   export VULTR_API_KEY=...
   export VULTR_SSHKEY_ID=...        # optional but recommended
   deploy/vultr/create_server.sh      # or: create_server.sh yto vc2-1c-1gb
   ```
   It prints the server IP. `deploy/vultr/cloud-init.yaml` installs Docker and opens only ports 22, 80 and 443.
   (You can also create the server by hand in the Vultr dashboard and paste `cloud-init.yaml` into *User Data*.)
3. **Fill in `.env`** (copy `.env.example`: Tiger Data URL, Snowflake settings, `ADMIN_TOKEN`).
4. **Deploy:**
   ```
   deploy/vultr/deploy.sh root@SERVER_IP                # plain HTTP on the IP
   deploy/vultr/deploy.sh root@SERVER_IP yourdomain.com # HTTPS, once the domain's A record points at the IP
   ```
   On Windows PowerShell, first rename `deploy\vultr\deploy.ps1.txt` to `deploy.ps1` (it ships as .txt so antivirus doesn't flag the zip), then run `.\deploy\vultr\deploy.ps1 root@SERVER_IP yourdomain.com` (the `.sh` scripts need bash).
   It copies the project and `.env` to the server, runs `docker compose up -d --build`, and checks `/api/health`.
5. **Redeploy** after any change by running the same `deploy.sh` command again.

## Custom domain (GoDaddy Registry)

The live site is https://resiliencerewired.biz (a `.biz` domain from GoDaddy Registry, registered through Porkbun).

1. At the registrar, add two **A records**: host blank (`@`) and host `www`, both pointing at the Vultr server IP.
2. Check it: `nslookup resiliencerewired.biz 1.1.1.1` should return the server IP.
3. Deploy with the domain, e.g. `.\deploy\vultr\deploy.ps1 root@SERVER_IP "resiliencerewired.biz, www.resiliencerewired.biz"`.
   Caddy then gets a free Let's Encrypt certificate automatically, so the site loads over HTTPS.

The server reports `host.provider = vultr` in `/api/health` (set by `HOST_PROVIDER` in `deploy/vultr/docker-compose.yml`). The header and the Data systems tab show "Hosted on Vultr" from that value, so they cannot claim Vultr when the app is running elsewhere.
