const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const appSource = fs.readFileSync(path.join(__dirname, '../dist/app.js'), 'utf8');
const projectionSource = appSource.match(/function renderProjection\(sc\) \{[\s\S]*?\n\}\n/);
assert.ok(projectionSource, 'Projection renderer exists');

const nodes = new Map();
const el = (selector) => {
  if (!nodes.has(selector)) {
    nodes.set(selector, {
      value: '', checked: false, disabled: false, textContent: '', innerHTML: '',
      setAttribute(key, value) { this[key] = value; },
    });
  }
  return nodes.get(selector);
};
const charts = [];
const context = vm.createContext({
  $: el,
  state: { shock: { income: 100 } },
  svgChart: (labels, series) => {
    charts.push({ labels, values: series[0].values });
    return '<svg></svg>';
  },
  getComputedStyle: () => ({ getPropertyValue: () => '#ed7210' }),
  document: { documentElement: {} },
  money: (amount) => `$${Math.round(amount).toLocaleString('en-CA')}`,
});
vm.runInContext(projectionSource[0], context);

const scenario = { remaining: 12000, afterIncome: 1000, afterSpending: 1500 };
el('#ei-duration').value = '3';

for (const horizon of [1, 6, 12, 24]) {
  el('#outlook-months').value = String(horizon);
  context.renderProjection(scenario);
  assert.equal(charts.at(-1).values.length, horizon + 1, `${horizon} month points`);
  assert.equal(el('#projection-window-label').textContent, `${horizon} MONTH OUTLOOK`);
  assert.equal(charts.at(-1).values.at(-1), 12000 - 500 * horizon);
}

assert.equal(el('#ei-duration').disabled, true, 'EI duration inactive by default');
context.state.shock.income = 55;
el('#ei-expiry').checked = true;
el('#outlook-months').value = '6';
context.renderProjection(scenario);
assert.equal(el('#ei-duration').disabled, false);
assert.equal(charts.at(-1).values[3], 10500, 'EI model retains income through month 3');
assert.equal(charts.at(-1).values[4], 9000, 'EI model stops income after month 3');
assert.equal(charts.at(-1).values.length, 7, 'EI expiry does not change graph horizon');

console.log('Projection test passed for 1, 6, 12, 24 months and separate EI timing.');
