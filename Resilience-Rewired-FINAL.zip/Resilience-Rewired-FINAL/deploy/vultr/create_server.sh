#!/usr/bin/env bash
# Creates a small Vultr cloud server (Ubuntu + Docker) through the Vultr API.
#
#   export VULTR_API_KEY=...          # my.vultr.com > Account > API (allow your IP)
#   export VULTR_SSHKEY_ID=...        # optional: id of an SSH key saved in Vultr
#   deploy/vultr/create_server.sh [region] [plan]
#
# Defaults: region yto (Toronto), plan vc2-1c-1gb (about $5/month, plenty for this app).
set -euo pipefail
: "${VULTR_API_KEY:?Set VULTR_API_KEY first}"
REGION="${1:-yto}"
PLAN="${2:-vc2-1c-1gb}"
HERE="$(cd "$(dirname "$0")" && pwd)"
API=https://api.vultr.com/v2
auth=(-H "Authorization: Bearer $VULTR_API_KEY" -H "Content-Type: application/json")

# Find the Ubuntu 24.04 image id instead of hard-coding it.
OS_ID=$(curl -fsS "${auth[@]}" "$API/os?per_page=500" | python3 -c '
import json, sys
for o in json.load(sys.stdin)["os"]:
    if o["name"].startswith("Ubuntu 24.04") and o["arch"] == "x64":
        print(o["id"]); break
else:
    sys.exit("Ubuntu 24.04 not found")')

BODY=$(python3 - "$REGION" "$PLAN" "$OS_ID" "$HERE/cloud-init.yaml" <<'PY'
import base64, json, os, sys
region, plan, os_id, ci = sys.argv[1:5]
body = {"region": region, "plan": plan, "os_id": int(os_id),
        "label": "resilience-rewired", "hostname": "resilience-rewired",
        "user_data": base64.b64encode(open(ci, "rb").read()).decode()}
if os.environ.get("VULTR_SSHKEY_ID"):
    body["sshkey_id"] = [os.environ["VULTR_SSHKEY_ID"]]
print(json.dumps(body))
PY
)

echo "Creating server in $REGION ($PLAN)..."
ID=$(curl -fsS "${auth[@]}" -X POST -d "$BODY" "$API/instances" | python3 -c 'import json,sys; print(json.load(sys.stdin)["instance"]["id"])')
echo "Instance $ID created. Waiting for an IP address..."

for _ in $(seq 1 40); do
  read -r IP STATUS <<<"$(curl -fsS "${auth[@]}" "$API/instances/$ID" | python3 -c '
import json, sys
i = json.load(sys.stdin)["instance"]
print(i["main_ip"], i["status"])')"
  if [ "$IP" != "0.0.0.0" ] && [ "$STATUS" = "active" ]; then
    echo "Server ready: $IP"
    echo "Next: deploy/vultr/deploy.sh root@$IP   (wait about 2 minutes for Docker to install)"
    exit 0
  fi
  sleep 10
done
echo "Still starting. Check my.vultr.com for the IP, then run deploy.sh." >&2
exit 1
