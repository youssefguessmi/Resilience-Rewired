#!/usr/bin/env bash
# Copies the project to the Vultr server and (re)starts it with Docker Compose.
#
#   deploy/vultr/deploy.sh root@SERVER_IP [domain]
#
# Needs a .env in the project root (copy .env.example). Secrets go to the server only; .env is never committed.
# With a domain whose DNS A record points at the server, Caddy gets a free HTTPS certificate.
set -euo pipefail
TARGET="${1:?Usage: deploy.sh root@SERVER_IP [domain]}"
DOMAIN="${2:-}"
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
[ -f "$ROOT/.env" ] || { echo "Missing $ROOT/.env (copy .env.example and fill it in)" >&2; exit 1; }

echo "Waiting for the server to finish installing Docker..."
for _ in $(seq 1 30); do
  ssh -o StrictHostKeyChecking=accept-new "$TARGET" 'test -f /opt/resilience/.cloud-init-done' 2>/dev/null && break
  sleep 10
done

rsync -az --delete \
  --exclude '.git' --exclude '__pycache__' --exclude 'tests' --exclude '.env' \
  "$ROOT/" "$TARGET:/opt/resilience/"
scp -q "$ROOT/.env" "$TARGET:/opt/resilience/.env"

ADDR=":80"; [ -n "$DOMAIN" ] && ADDR="$DOMAIN"
ssh "$TARGET" "cd /opt/resilience/deploy/vultr && SITE_ADDRESS='$ADDR' docker compose up -d --build"

HOST="${TARGET#*@}"
echo "Deployed. Checking health..."
sleep 5
URL="http://$HOST"; [ -n "$DOMAIN" ] && URL="https://$DOMAIN"
curl -fsS "$URL/api/health" && echo && echo "Open $URL"
