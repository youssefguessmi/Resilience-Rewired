"""One-time load: create the Snowflake objects, upload all 9 CSVs, build features and findings.

  pip install snowflake-connector-python
  SNOWFLAKE_ACCOUNT=myorg-myaccount SNOWFLAKE_USER=... SNOWFLAKE_PASSWORD=... \
    python scripts/snowflake_load.py /path/to/data

SNOWFLAKE_PASSWORD can be a password or a programmatic access token. File upload (PUT)
needs the Python connector; everything after the load can run through the SQL API
(scripts/sync_to_tiger.py --rebuild, or the app's /api/refresh).
"""
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
import envfile  # noqa: E402

envfile.load_env()
SQL = ROOT / "integrations" / "snowflake"
FILES = {
    "accounts": "ACCOUNTS", "cards": "CARDS", "clients": "CLIENTS",
    "dispositions": "DISPOSITIONS", "districts": "DISTRICTS", "loans": "LOANS",
    "monthly_summary": "MONTHLY_SUMMARY", "standing_orders": "STANDING_ORDERS",
    "transactions": "TRANSACTIONS",
}


def statements(text):
    """Split a .sql file into single statements. Comment-only leftovers (such as the notes at the
    end of 01_setup.sql) are dropped, because Snowflake rejects them as 'Empty SQL statement'."""
    lines = [line for line in text.splitlines() if not line.strip().startswith("--")]
    return [part.strip() for part in "\n".join(lines).split(";") if part.strip()]


def run_file(cur, path):
    for statement in statements(path.read_text()):
        cur.execute(statement)


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    data = Path(sys.argv[1]).resolve()
    missing = [n for n in FILES if not (data / f"{n}.csv").exists()]
    if missing:
        sys.exit(f"Missing CSVs in {data}: {', '.join(missing)}")

    import snowflake.connector  # imported here so the rest of the repo doesn't need it

    conn = snowflake.connector.connect(
        account=os.environ["SNOWFLAKE_ACCOUNT"], user=os.environ["SNOWFLAKE_USER"],
        password=os.environ["SNOWFLAKE_PASSWORD"], role=os.environ.get("SNOWFLAKE_ROLE"))
    started = time.time()
    try:
        print("Creating warehouse, database, stage and tables...")
        cur = conn.cursor()
        run_file(cur, SQL / "01_setup.sql")
        cur.execute("USE SCHEMA RESILIENCE.CORE")
        for name, table in FILES.items():
            path = (data / f"{name}.csv").as_posix()
            print(f"Uploading {name}.csv...")
            cur.execute(f"PUT 'file://{path}' @RAW_STAGE AUTO_COMPRESS=TRUE OVERWRITE=TRUE")
            cur.execute(f"COPY INTO {table} FROM @RAW_STAGE/{name}.csv.gz ON_ERROR='ABORT_STATEMENT'")
            count = cur.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            print(f"  {table}: {count:,} rows")
        for name in ("02_features.sql", "03_findings.sql"):
            print(f"Running {name}...")
            run_file(cur, SQL / name)
        n = cur.execute("SELECT COUNT(*) FROM ACCOUNT_FEATURES").fetchone()[0]
        f = cur.execute("SELECT COUNT(*) FROM FINDINGS").fetchone()[0]
        print(f"Done in {time.time() - started:.0f}s: {n:,} accounts, {f} finding rows.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
