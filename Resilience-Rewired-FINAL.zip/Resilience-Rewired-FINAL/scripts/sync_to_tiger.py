"""Load Tiger Data from Snowflake (or from the local CSVs for offline work).

  # Production path: Snowflake computes, the SQL API returns results, Tiger Data stores them
  TIGER_DATABASE_URL=... SNOWFLAKE_ACCOUNT=... SNOWFLAKE_PAT=... \
    python scripts/sync_to_tiger.py --source snowflake

  # Add --rebuild to rerun 02_features.sql and 03_findings.sql in Snowflake first.

  # Offline path: same SQL run locally in DuckDB (labelled 'local-duckdb', not Snowflake)
  TIGER_DATABASE_URL=... python scripts/sync_to_tiger.py --source local --data /path/to/data
"""
import argparse
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))

import envfile  # noqa: E402

envfile.load_env()
import psycopg  # noqa: E402

import sync  # noqa: E402
from snowflake_api import SnowflakeSQLAPI  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--source", choices=["snowflake", "local"], required=True)
    parser.add_argument("--data", help="folder with the challenge CSVs (local source)")
    parser.add_argument("--rebuild", action="store_true", help="recompute in Snowflake first")
    parser.add_argument("--tables", default="account_features,findings,account_monthly")
    args = parser.parse_args()

    url = os.environ.get("TIGER_DATABASE_URL")
    if not url:
        sys.exit("Set TIGER_DATABASE_URL to your Tiger Data connection string.")
    tables = [t.strip() for t in args.tables.split(",") if t.strip()]

    started = time.time()
    if args.source == "snowflake":
        client = SnowflakeSQLAPI.from_env()
        if not client:
            sys.exit("Set SNOWFLAKE_ACCOUNT and SNOWFLAKE_PAT.")
        if args.rebuild:
            print("Rebuilding ACCOUNT_FEATURES and FINDINGS in Snowflake...")
            sync.rebuild_in_snowflake(client)
        data = sync.fetch_snowflake(client, tables)
        source = "snowflake"
    else:
        if not args.data:
            sys.exit("--data is required with --source local")
        data = sync.fetch_local(args.data, tables)
        source = "local-duckdb"
    print("Fetched " + ", ".join(f"{t}: {len(r):,} rows" for t, r in data.items()))

    with psycopg.connect(url) as conn:
        sync.ensure_schema(conn)
        total = sync.write_tiger(conn, data, source)
    print(f"Wrote {total:,} rows to Tiger Data from {source} in {time.time() - started:.1f}s")


if __name__ == "__main__":
    main()
