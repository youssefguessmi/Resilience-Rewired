-- Resilience Rewired: cross-account findings, computed from ACCOUNT_FEATURES.
-- One row per finding and group. RATE_PCT is the headline percentage for that row,
-- described by RATE_LABEL. The app's Discoveries tab reads this table (via Tiger Data).

CREATE OR REPLACE TABLE FINDINGS AS
WITH F AS (
  SELECT *, COALESCE(RUNWAY_EI, 999) AS EI_RUN FROM ACCOUNT_FEATURES
)
-- 1. Income paradox: higher earners hold fewer months of savings.
SELECT 'income_paradox' AS FINDING,
  'Higher earners are the most fragile under a 55% EI shock' AS HEADLINE,
  CASE INCOME_GROUP WHEN 1 THEN 'Lowest 25% of earners' WHEN 2 THEN 'Second 25%'
                    WHEN 3 THEN 'Third 25%' ELSE 'Highest 25% of earners' END AS GROUP_LABEL,
  INCOME_GROUP AS SORT_ORDER,
  COUNT(*) AS ACCOUNTS,
  ROUND(100.0 * SUM(CASE WHEN EI_RUN < 6 THEN 1 ELSE 0 END) / COUNT(*), 1) AS RATE_PCT,
  'under 6 months of runway on EI' AS RATE_LABEL,
  ROUND(MEDIAN(I), 0) AS MEDIAN_MONEY_IN,
  ROUND(MEDIAN(BUFFER_MONTHS), 2) AS MEDIAN_BUFFER_MONTHS
FROM F WHERE INCOME_GROUP IS NOT NULL
GROUP BY INCOME_GROUP

UNION ALL
-- 2. Going below zero before a loan.
SELECT 'below_zero_before_loan',
  'Every borrower who went below zero before their loan later defaulted',
  CASE WHEN PRE_LOAN_DAYS_BELOW_ZERO > 0 THEN 'Went below $0 before the loan'
       ELSE 'Never below $0 before the loan' END,
  CASE WHEN PRE_LOAN_DAYS_BELOW_ZERO > 0 THEN 1 ELSE 2 END,
  COUNT(*),
  ROUND(100.0 * SUM(LOAN_DEFAULTED) / COUNT(*), 1),
  'of these loans defaulted',
  NULL, NULL
FROM F WHERE LOAN_STATUS IS NOT NULL
GROUP BY CASE WHEN PRE_LOAN_DAYS_BELOW_ZERO > 0 THEN 1 ELSE 2 END,
         CASE WHEN PRE_LOAN_DAYS_BELOW_ZERO > 0 THEN 'Went below $0 before the loan'
              ELSE 'Never below $0 before the loan' END

UNION ALL
-- 3. The EI cliff: last 6 months on EI, then income stops.
SELECT 'ei_cliff',
  'Most people who survive 6 months on EI run out soon after it ends',
  'Run out by month 9', 1, COUNT(*),
  ROUND(100.0 * SUM(CASE WHEN EI_CLIFF_MONTHS < 9 THEN 1 ELSE 0 END) / COUNT(*), 1),
  'of working-age customers who last 6+ months on EI', NULL, NULL
FROM F WHERE INCOME_SOURCE <> 'pension' AND EI_RUN >= 6
UNION ALL
SELECT 'ei_cliff',
  'Most people who survive 6 months on EI run out soon after it ends',
  'Run out by month 12', 2, COUNT(*),
  ROUND(100.0 * SUM(CASE WHEN EI_CLIFF_MONTHS < 12 THEN 1 ELSE 0 END) / COUNT(*), 1),
  'of working-age customers who last 6+ months on EI', NULL, NULL
FROM F WHERE INCOME_SOURCE <> 'pension' AND EI_RUN >= 6

UNION ALL
-- 4. Everyone, under the judges' 55% EI shock.
SELECT 'overall', 'All 4,500 customers under a 55% EI shock',
  'Under 6 months of runway', 1, COUNT(*),
  ROUND(100.0 * SUM(CASE WHEN EI_RUN < 6 THEN 1 ELSE 0 END) / COUNT(*), 1),
  'of all customers', ROUND(MEDIAN(I), 0), ROUND(MEDIAN(BUFFER_MONTHS), 2)
FROM F
UNION ALL
SELECT 'overall', 'All 4,500 customers under a 55% EI shock',
  'Under 3 months of runway', 2, COUNT(*),
  ROUND(100.0 * SUM(CASE WHEN EI_RUN < 3 THEN 1 ELSE 0 END) / COUNT(*), 1),
  'of all customers', NULL, NULL
FROM F
UNION ALL
SELECT 'overall', 'All 4,500 customers under a 55% EI shock',
  'Already spend more than they earn', 3, COUNT(*),
  ROUND(100.0 * SUM(CASE WHEN S > I THEN 1 ELSE 0 END) / COUNT(*), 1),
  'of all customers, before any shock', NULL, NULL
FROM F

UNION ALL
-- 5. Ever below zero, across all accounts.
SELECT 'ever_below_zero', 'Going below zero is a strong warning sign',
  CASE WHEN DAYS_BELOW_ZERO > 0 THEN 'Ever below $0' ELSE 'Never below $0' END,
  CASE WHEN DAYS_BELOW_ZERO > 0 THEN 1 ELSE 2 END,
  COUNT(*),
  ROUND(100.0 * SUM(CASE WHEN EI_RUN < 3 THEN 1 ELSE 0 END) / COUNT(*), 1),
  'under 3 months of runway on EI', NULL, ROUND(MEDIAN(BUFFER_MONTHS), 2)
FROM F
GROUP BY CASE WHEN DAYS_BELOW_ZERO > 0 THEN 1 ELSE 2 END,
         CASE WHEN DAYS_BELOW_ZERO > 0 THEN 'Ever below $0' ELSE 'Never below $0' END

UNION ALL
-- 6. Loan affordability: savings before the loan.
SELECT 'loan_savings_before', 'Thin savings before a loan go with far more defaults',
  BAND, SORT_KEY, COUNT(*), ROUND(100.0 * SUM(LOAN_DEFAULTED) / COUNT(*), 1),
  'of these loans defaulted', NULL, NULL
FROM (
  SELECT LOAN_DEFAULTED,
    CASE WHEN PRE_LOAN_BUFFER_MONTHS < 1 THEN 'Under 1 month saved'
         WHEN PRE_LOAN_BUFFER_MONTHS < 2 THEN '1 to 2 months saved'
         WHEN PRE_LOAN_BUFFER_MONTHS < 4 THEN '2 to 4 months saved'
         ELSE '4+ months saved' END AS BAND,
    CASE WHEN PRE_LOAN_BUFFER_MONTHS < 1 THEN 1 WHEN PRE_LOAN_BUFFER_MONTHS < 2 THEN 2
         WHEN PRE_LOAN_BUFFER_MONTHS < 4 THEN 3 ELSE 4 END AS SORT_KEY
  FROM F WHERE LOAN_STATUS IS NOT NULL AND PRE_LOAN_BUFFER_MONTHS IS NOT NULL
) X
GROUP BY BAND, SORT_KEY

UNION ALL
-- 7. Loan affordability: payment as a share of income before the loan.
SELECT 'loan_payment_share', 'Big payments relative to income go with more defaults',
  BAND, SORT_KEY, COUNT(*), ROUND(100.0 * SUM(LOAN_DEFAULTED) / COUNT(*), 1),
  'of these loans defaulted', NULL, NULL
FROM (
  SELECT LOAN_DEFAULTED,
    CASE WHEN PRE_LOAN_PAYMENT_SHARE < 0.15 THEN 'Payment under 15% of income'
         WHEN PRE_LOAN_PAYMENT_SHARE < 0.30 THEN '15% to 30% of income'
         WHEN PRE_LOAN_PAYMENT_SHARE < 0.50 THEN '30% to 50% of income'
         ELSE 'Over 50% of income' END AS BAND,
    CASE WHEN PRE_LOAN_PAYMENT_SHARE < 0.15 THEN 1 WHEN PRE_LOAN_PAYMENT_SHARE < 0.30 THEN 2
         WHEN PRE_LOAN_PAYMENT_SHARE < 0.50 THEN 3 ELSE 4 END AS SORT_KEY
  FROM F WHERE LOAN_STATUS IS NOT NULL AND PRE_LOAN_PAYMENT_SHARE IS NOT NULL
) X
GROUP BY BAND, SORT_KEY

UNION ALL
-- 8. Emergency fund groups (drives which plan each customer sees).
SELECT 'emergency_fund', 'Customers need different savings plans',
  EMERGENCY_FUND_GROUP,
  CASE EMERGENCY_FUND_GROUP WHEN 'has 3 months' THEN 1 WHEN 'within 12 months' THEN 2
                            WHEN 'over 12 months' THEN 3 ELSE 4 END,
  COUNT(*), ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM ACCOUNT_FEATURES), 1),
  'of all customers', NULL, NULL
FROM F
GROUP BY EMERGENCY_FUND_GROUP;
