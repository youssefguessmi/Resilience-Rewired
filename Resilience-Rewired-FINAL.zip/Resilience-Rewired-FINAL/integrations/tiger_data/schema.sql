-- Resilience Rewired: Tiger Data (Postgres + TimescaleDB) serving database.
-- Snowflake computes; Tiger Data serves. The app server reads one customer at a
-- time from here, so lookups are fast and Snowflake is only woken for a refresh.
-- Safe to re-run. Works on plain Postgres too (the TimescaleDB parts are skipped).

CREATE TABLE IF NOT EXISTS account_monthly (
  account_id        INTEGER NOT NULL,
  month             DATE    NOT NULL,          -- first day of the month
  money_in          DOUBLE PRECISION NOT NULL,
  money_out         DOUBLE PRECISION NOT NULL,
  pension_in        DOUBLE PRECISION NOT NULL,
  household_bills   DOUBLE PRECISION NOT NULL,
  insurance         DOUBLE PRECISION NOT NULL,
  loan_payments     DOUBLE PRECISION NOT NULL,
  avg_daily_balance DOUBLE PRECISION NOT NULL,
  min_balance       DOUBLE PRECISION NOT NULL,
  days_below_zero   INTEGER NOT NULL,
  PRIMARY KEY (account_id, month)
);

CREATE TABLE IF NOT EXISTS account_features (
  account_id               INTEGER PRIMARY KEY,
  months                   INTEGER,
  first_month              TEXT,
  last_month               TEXT,
  i                        DOUBLE PRECISION,  -- typical money in
  s                        DOUBLE PRECISION,  -- typical spending
  f                        DOUBLE PRECISION,  -- typical fixed costs
  h                        DOUBLE PRECISION,  -- typical household bills
  b                        DOUBLE PRECISION,  -- savings buffer
  p                        DOUBLE PRECISION,  -- running loan payment
  h_for_shocks             DOUBLE PRECISION,  -- h, or bills recovered from standing orders
  income_source            TEXT,
  income_group             INTEGER,           -- 1-4, working-age income quartile
  cushion                  DOUBLE PRECISION,
  buffer_months            DOUBLE PRECISION,
  worst_month_extra        DOUBLE PRECISION,
  days_below_zero          INTEGER,
  income_variation         DOUBLE PRECISION,
  committed_monthly        DOUBLE PRECISION,
  owner_age                INTEGER,
  people_on_account        INTEGER,
  district_name            TEXT,
  region                   TEXT,
  loan_status              TEXT,
  loan_amount              DOUBLE PRECISION,
  loan_payment             DOUBLE PRECISION,
  loan_defaulted           INTEGER,
  pre_loan_days_below_zero INTEGER,
  pre_loan_buffer_months   DOUBLE PRECISION,
  pre_loan_payment_share   DOUBLE PRECISION,
  runway_base              DOUBLE PRECISION,  -- NULL = no shortfall
  runway_ei                DOUBLE PRECISION,  -- NULL = no shortfall
  ei_cliff_months          DOUBLE PRECISION,
  emergency_fund_group     TEXT
);

CREATE TABLE IF NOT EXISTS findings (
  finding              TEXT NOT NULL,
  headline             TEXT NOT NULL,
  group_label          TEXT NOT NULL,
  sort_order           INTEGER NOT NULL,
  accounts             INTEGER NOT NULL,
  rate_pct             DOUBLE PRECISION,
  rate_label           TEXT,
  median_money_in      DOUBLE PRECISION,
  median_buffer_months DOUBLE PRECISION,
  PRIMARY KEY (finding, group_label)
);

CREATE TABLE IF NOT EXISTS sync_log (
  synced_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  source     TEXT NOT NULL,        -- 'snowflake' or 'local-duckdb'
  tables     TEXT NOT NULL,
  row_count  INTEGER NOT NULL
);

-- The judges' runway formula, in the database. NULL means "no shortfall (120+)".
CREATE OR REPLACE FUNCTION runway(buffer DOUBLE PRECISION, income DOUBLE PRECISION,
                                  spending DOUBLE PRECISION, one_off DOUBLE PRECISION DEFAULT 0)
RETURNS DOUBLE PRECISION LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE WHEN buffer - one_off <= 0 THEN 0
              WHEN spending - income <= 0 THEN NULL
              ELSE LEAST((buffer - one_off) / (spending - income), 120) END
$$;

-- Apply a shock to one customer, using their stored numbers.
CREATE OR REPLACE FUNCTION scenario(p_account INTEGER, income_pct DOUBLE PRECISION DEFAULT 100,
                                    bills_pct DOUBLE PRECISION DEFAULT 0,
                                    one_off DOUBLE PRECISION DEFAULT 0,
                                    extra_monthly DOUBLE PRECISION DEFAULT 0)
RETURNS TABLE (income_after DOUBLE PRECISION, spending_after DOUBLE PRECISION,
               buffer_left DOUBLE PRECISION, monthly_gap DOUBLE PRECISION,
               runway_months DOUBLE PRECISION)
LANGUAGE sql STABLE AS $$
  SELECT x.inc, x.spend, f.b - one_off, x.spend - x.inc, runway(f.b, x.inc, x.spend, one_off)
  FROM account_features f,
       LATERAL (SELECT f.i * income_pct / 100 AS inc,
                       f.s + f.h * bills_pct / 100 + extra_monthly AS spend) x
  WHERE f.account_id = p_account
$$;

-- TimescaleDB: make account_monthly a hypertable and add a yearly roll-up.
-- On plain Postgres (local tests) the same view uses date_trunc instead.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_available_extensions WHERE name = 'timescaledb') THEN
    CREATE EXTENSION IF NOT EXISTS timescaledb;
    PERFORM create_hypertable('account_monthly', by_range('month', INTERVAL '1 year'),
                              if_not_exists => TRUE, migrate_data => TRUE);
    EXECUTE $v$
      CREATE OR REPLACE VIEW account_yearly AS
      SELECT account_id, time_bucket(INTERVAL '1 year', month)::date AS year,
             sum(money_in) AS money_in, sum(money_out) AS money_out,
             avg(avg_daily_balance) AS avg_balance, sum(days_below_zero) AS days_below_zero
      FROM account_monthly GROUP BY 1, 2 $v$;
  ELSE
    EXECUTE $v$
      CREATE OR REPLACE VIEW account_yearly AS
      SELECT account_id, date_trunc('year', month)::date AS year,
             sum(money_in) AS money_in, sum(money_out) AS money_out,
             avg(avg_daily_balance) AS avg_balance, sum(days_below_zero) AS days_below_zero
      FROM account_monthly GROUP BY 1, 2 $v$;
  END IF;
END $$;
