"""Resilience Rewired app server: the website plus a small API over Tiger Data and Snowflake.

  Snowflake  -> computes features and findings from all 9 CSVs (the analysis engine)
  Tiger Data -> stores them and serves one customer at a time (the serving database)
  This server-> reads Tiger Data for the website, and asks Snowflake to recompute on /api/refresh

Endpoints
  GET  /api/health                      which backends are connected, and when data last synced
  GET  /api/accounts                    all account IDs
  GET  /api/account/<id>                one customer, same shape as dist/data/accounts.json + extras
  GET  /api/findings                    cross-account findings computed in Snowflake
  GET  /api/scenario?account=&income=&bills=&repair=&extra=   shock math run inside Tiger Data
  POST /api/refresh  (X-Admin-Token)    recompute in Snowflake via the SQL API, then reload Tiger Data

With no TIGER_DATABASE_URL the API reports itself offline and the website falls back to its
built-in data files, so the demo still works if a cloud service is unreachable.

Run:  TIGER_DATABASE_URL=... SNOWFLAKE_ACCOUNT=... SNOWFLAKE_PAT=... ADMIN_TOKEN=... \
        python server/app.py      (PORT defaults to 8080)
"""
import json
import mimetypes
import os
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envfile  # noqa: E402

envfile.load_env()
import sync  # noqa: E402
from snowflake_api import SnowflakeError, SnowflakeSQLAPI  # noqa: E402

DIST = (Path(__file__).resolve().parents[1] / "dist").resolve()
TIGER_URL = os.environ.get("TIGER_DATABASE_URL", "")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")


class Tiger:
    """One shared connection to Tiger Data, reconnected on failure."""

    def __init__(self, url):
        self.url = url
        self.conn = None
        self.lock = threading.Lock()

    def _connect(self):
        import psycopg
        from psycopg.rows import dict_row
        self.conn = psycopg.connect(self.url, autocommit=True, row_factory=dict_row,
                                    connect_timeout=5)

    def query(self, sql, params=()):
        if not self.url:
            raise ConnectionError("TIGER_DATABASE_URL is not set")
        with self.lock:
            for attempt in (1, 2):
                try:
                    if self.conn is None or self.conn.closed:
                        self._connect()
                    with self.conn.cursor() as cur:
                        cur.execute(sql, params)
                        return cur.fetchall() if cur.description else []
                except Exception:
                    self.conn = None
                    if attempt == 2:
                        raise

    def write(self, data, source):
        import psycopg
        with self.lock, psycopg.connect(self.url, connect_timeout=5) as conn:
            sync.ensure_schema(conn)
            return sync.write_tiger(conn, data, source)


tiger = Tiger(TIGER_URL)
snowflake = SnowflakeSQLAPI.from_env()
last_refresh = {}


def r2(value):
    return None if value is None else round(float(value), 2)


def r1(value):
    return None if value is None else round(float(value), 1)


def health():
    out = {"tiger": {"connected": False}, "snowflake": {"configured": bool(snowflake)},
           "host": {"provider": os.environ.get("HOST_PROVIDER") or None,
                    "region": os.environ.get("HOST_REGION") or None},
           "last_refresh": last_refresh or None}
    try:
        n = tiger.query("SELECT count(*) AS n FROM account_features")[0]["n"]
        log = tiger.query("SELECT synced_at, source FROM sync_log ORDER BY synced_at DESC LIMIT 1")
        out["tiger"] = {"connected": n > 0, "accounts": n,
                        "last_sync": log[0]["synced_at"].isoformat() if log else None,
                        "source": log[0]["source"] if log else None}
    except Exception as err:  # offline is a normal state, not a crash
        out["tiger"]["error"] = str(err).splitlines()[0][:200]
    return out


def account(account_id):
    rows = tiger.query("SELECT * FROM account_features WHERE account_id = %s", (account_id,))
    if not rows:
        return None
    f = rows[0]
    series = tiger.query(
        "SELECT to_char(month, 'YYYY-MM') AS m, money_in, money_out, avg_daily_balance, "
        "household_bills FROM account_monthly WHERE account_id = %s ORDER BY month", (account_id,))
    yearly = tiger.query(
        "SELECT to_char(year, 'YYYY') AS year, money_in, money_out, avg_balance, days_below_zero "
        "FROM account_yearly WHERE account_id = %s ORDER BY year", (account_id,))
    loan = None
    if f["loan_status"]:
        loan = {"status": f["loan_status"], "payment": r2(f["loan_payment"]),
                "amount": r2(f["loan_amount"]), "defaulted": bool(f["loan_defaulted"])}
    extras = {k: (r2(v) if isinstance(v, float) else v) for k, v in f.items()}
    return {
        "id": str(f["account_id"]), "months": f["months"], "first": f["first_month"],
        "last": f["last_month"], "I": r2(f["i"]), "S": r2(f["s"]), "F": r2(f["f"]),
        "H": r2(f["h"]), "B": r2(f["b"]), "P": r2(f["p"]), "loan": loan,
        "district": f["district_name"] or "Unknown", "region": f["region"] or "Unknown",
        "base_runway": r1(f["runway_base"]), "job_runway": r1(f["runway_ei"]),
        "series": [[s["m"], r2(s["money_in"]), r2(s["money_out"]), r2(s["avg_daily_balance"]),
                    r2(s["household_bills"])] for s in series],
        "yearly": [{k: (r2(v) if isinstance(v, float) else v) for k, v in y.items()} for y in yearly],
        "features": extras,
        "source": "tiger",
    }


def findings():
    rows = tiger.query("SELECT * FROM findings ORDER BY finding, sort_order")
    log = tiger.query("SELECT synced_at, source FROM sync_log WHERE tables LIKE %s "
                      "ORDER BY synced_at DESC LIMIT 1", ("%findings%",))
    return {"source": log[0]["source"] if log else None,
            "synced_at": log[0]["synced_at"].isoformat() if log else None,
            "findings": rows}


def scenario(q):
    def num(name, default):
        value = float(q.get(name, [default])[0])
        if value != value or abs(value) > 1e9:
            raise ValueError(name)
        return value
    acct = int(q["account"][0])
    rows = tiger.query("SELECT * FROM scenario(%s, %s, %s, %s, %s)",
                       (acct, num("income", 100), num("bills", 0), num("repair", 0), num("extra", 0)))
    if not rows:
        return None
    s = rows[0]
    runway_months = s["runway_months"]
    return {"account": acct, "income_after": r2(s["income_after"]),
            "spending_after": r2(s["spending_after"]), "buffer_left": r2(s["buffer_left"]),
            "monthly_gap": r2(s["monthly_gap"]),
            "runway_months": r1(runway_months),
            "runway_text": "no shortfall (120+)" if runway_months is None else f"{runway_months:.1f}",
            "computed_in": "Tiger Data"}


def refresh():
    if not snowflake:
        raise RuntimeError("Snowflake is not configured (SNOWFLAKE_ACCOUNT, SNOWFLAKE_PAT)")
    started = time.time()
    sync.rebuild_in_snowflake(snowflake)
    data = sync.fetch_snowflake(snowflake, ["account_features", "findings"])
    rows = tiger.write(data, "snowflake")
    last_refresh.clear()
    last_refresh.update({"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                         "rows": rows, "seconds": round(time.time() - started, 1)})
    return dict(last_refresh)


class Handler(BaseHTTPRequestHandler):
    server_version = "ResilienceRewired/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s %s\n" % (self.command, self.path))

    def _json(self, code, payload):
        body = json.dumps(payload, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _api(self, fn, *args):
        try:
            result = fn(*args)
            if result is None:
                return self._json(404, {"error": "not found"})
            self._json(200, result)
        except (KeyError, ValueError):
            self._json(400, {"error": "bad request"})
        except SnowflakeError as err:
            self._json(502, {"error": str(err)})
        except Exception as err:
            traceback.print_exc()
            self._json(503, {"error": str(err).splitlines()[0][:200] if str(err) else "unavailable"})

    def do_GET(self):
        url = urlparse(self.path)
        path, query = url.path, parse_qs(url.query)
        if path == "/api/health":
            return self._json(200, health())
        if path == "/api/accounts":
            return self._api(lambda: {"ids": [str(r["account_id"]) for r in tiger.query(
                "SELECT account_id FROM account_features ORDER BY account_id")]})
        if path.startswith("/api/account/"):
            ident = path.rsplit("/", 1)[-1]
            if not ident.isdigit():
                return self._json(400, {"error": "account id must be a number"})
            return self._api(account, int(ident))
        if path == "/api/findings":
            return self._api(findings)
        if path == "/api/scenario":
            return self._api(scenario, query)
        if path.startswith("/api/"):
            return self._json(404, {"error": "unknown endpoint"})
        self._static(path)

    def do_POST(self):
        if urlparse(self.path).path != "/api/refresh":
            return self._json(404, {"error": "unknown endpoint"})
        if not ADMIN_TOKEN or self.headers.get("X-Admin-Token") != ADMIN_TOKEN:
            return self._json(403, {"error": "refresh needs a valid X-Admin-Token"})
        self._api(refresh)

    def _static(self, path):
        target = (DIST / (path.lstrip("/") or "index.html")).resolve()
        if target.is_dir():
            target = target / "index.html"
        inside_dist = DIST in target.parents  # blocks ../ path traversal
        if not inside_dist or not target.is_file():
            return self._json(404, {"error": "not found"})
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main():
    port = int(os.environ.get("PORT", "8080"))
    print(f"Resilience Rewired on http://0.0.0.0:{port}  "
          f"(Tiger Data: {'configured' if TIGER_URL else 'not set'}, "
          f"Snowflake: {'configured' if snowflake else 'not set'})")
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()


if __name__ == "__main__":
    main()
