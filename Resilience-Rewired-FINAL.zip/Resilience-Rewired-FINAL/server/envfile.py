"""Reads the project's .env file into os.environ (works on Windows, Mac and Linux).

Real environment variables win over the file. Lines look like KEY=value; '#' starts a comment.
"""
import os
from pathlib import Path


def load_env(path=None):
    path = Path(path) if path else Path(__file__).resolve().parents[1] / ".env"
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        key = key.strip()
        if key and value:
            os.environ.setdefault(key, value)
