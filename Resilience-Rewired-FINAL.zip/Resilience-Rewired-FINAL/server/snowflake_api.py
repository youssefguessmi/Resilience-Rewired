"""Minimal client for the Snowflake SQL API (REST), standard library only.

Authenticates with a programmatic access token (PAT):
  POST https://<account>.snowflakecomputing.com/api/v2/statements
  Authorization: Bearer <PAT>
  X-Snowflake-Authorization-Token-Type: PROGRAMMATIC_ACCESS_TOKEN

Environment variables:
  SNOWFLAKE_ACCOUNT    e.g. myorg-myaccount (the part before .snowflakecomputing.com)
  SNOWFLAKE_PAT        the programmatic access token
  SNOWFLAKE_WAREHOUSE  default RESILIENCE_WH
  SNOWFLAKE_DATABASE   default RESILIENCE
  SNOWFLAKE_SCHEMA     default CORE
  SNOWFLAKE_ROLE       optional
  SNOWFLAKE_API_URL    optional full base URL override (used by tests)
"""
import json
import os
import time
import urllib.error
import urllib.request
import uuid


class SnowflakeError(RuntimeError):
    pass


class SnowflakeSQLAPI:
    def __init__(self, account=None, token=None, warehouse=None, database=None,
                 schema=None, role=None, base_url=None, timeout=120):
        self.account = account or os.environ.get("SNOWFLAKE_ACCOUNT", "")
        self.token = token or os.environ.get("SNOWFLAKE_PAT", "")
        self.warehouse = warehouse or os.environ.get("SNOWFLAKE_WAREHOUSE", "RESILIENCE_WH")
        self.database = database or os.environ.get("SNOWFLAKE_DATABASE", "RESILIENCE")
        self.schema = schema or os.environ.get("SNOWFLAKE_SCHEMA", "CORE")
        self.role = role or os.environ.get("SNOWFLAKE_ROLE") or None
        self.base_url = (base_url or os.environ.get("SNOWFLAKE_API_URL")
                         or f"https://{self.account}.snowflakecomputing.com").rstrip("/")
        self.timeout = timeout

    @classmethod
    def from_env(cls):
        client = cls()
        return client if client.configured else None

    @property
    def configured(self):
        return bool(self.token and (self.account or os.environ.get("SNOWFLAKE_API_URL")))

    def _request(self, method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base_url + path, data=data, method=method, headers={
            "Authorization": f"Bearer {self.token}",
            "X-Snowflake-Authorization-Token-Type": "PROGRAMMATIC_ACCESS_TOKEN",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "resilience-rewired/1.0",
        })
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.status, json.loads(resp.read() or b"{}")
        except urllib.error.HTTPError as err:
            detail = err.read().decode(errors="replace")[:500]
            raise SnowflakeError(f"Snowflake SQL API {err.code}: {detail}") from None
        except urllib.error.URLError as err:
            raise SnowflakeError(f"Could not reach Snowflake: {err.reason}") from None

    def execute(self, statement):
        """Run one SQL statement. Returns (column_names, rows) with typed values."""
        body = {"statement": statement.strip().rstrip(";"), "timeout": self.timeout,
                "warehouse": self.warehouse, "database": self.database, "schema": self.schema}
        if self.role:
            body["role"] = self.role
        status, result = self._request("POST", f"/api/v2/statements?requestId={uuid.uuid4()}", body)
        handle = result.get("statementHandle")
        deadline = time.time() + self.timeout
        while status == 202:  # still running: poll the status URL
            if time.time() > deadline:
                raise SnowflakeError(f"Statement {handle} timed out")
            time.sleep(1)
            status, result = self._request("GET", f"/api/v2/statements/{handle}")
        meta = result.get("resultSetMetaData") or {}
        row_type = meta.get("rowType") or []
        columns = [c["name"] for c in row_type]
        rows = list(result.get("data") or [])
        # Large results arrive in partitions; partition 0 is in the first response.
        for index in range(1, len(meta.get("partitionInfo") or [])):
            _, part = self._request("GET", f"/api/v2/statements/{handle}?partition={index}")
            rows.extend(part.get("data") or [])
        return columns, [[_convert(v, c) for v, c in zip(row, row_type)] for row in rows]


def _convert(value, column):
    """The SQL API returns every value as a string; convert numbers back."""
    if value is None:
        return None
    kind = column.get("type", "").lower()
    if kind == "fixed":
        return int(value) if not column.get("scale") else float(value)
    if kind == "real":
        return float(value)
    return value
