"""Move Snowflake's results into Tiger Data.

Snowflake (via the SQL API) -> ACCOUNT_FEATURES, FINDINGS, MONTHLY_SUMMARY
                             -> Tiger Data tables account_features, findings, account_monthly

A local source runs the same SQL files in DuckDB, for offline development and tests.
Rows from it are labelled 'local-duckdb' in sync_log, so the app never claims Snowflake
produced them.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SQL_DIR = ROOT / "integrations" / "snowflake"
TIGER_SCHEMA = ROOT / "integrations" / "tiger_data" / "schema.sql"

FEATURE_COLUMNS = [
    "account_id", "months", "first_month", "last_month", "i", "s", "f", "h", "b", "p",
    "h_for_shocks", "income_source", "income_group", "cushion", "buffer_months",
    "worst_month_extra", "days_below_zero", "income_variation", "committed_monthly",
    "owner_age", "people_on_account", "district_name", "region", "loan_status", "loan_amount",
    "loan_payment", "loan_defaulted", "pre_loan_days_below_zero", "pre_loan_buffer_months",
    "pre_loan_payment_share", "runway_base", "runway_ei", "ei_cliff_months",
    "emergency_fund_group",
]
FINDING_COLUMNS = [
    "finding", "headline", "group_label", "sort_order", "accounts", "rate_pct", "rate_label",
    "median_money_in", "median_buffer_months",
]
MONTHLY_COLUMNS = [
    "account_id", "month", "money_in", "money_out", "pension_in", "household_bills",
    "insurance", "loan_payments", "avg_daily_balance", "min_balance", "days_below_zero",
]

SELECTS = {
    "account_features": "SELECT " + ", ".join(c.upper() for c in FEATURE_COLUMNS)
                        + " FROM ACCOUNT_FEATURES ORDER BY ACCOUNT_ID",
    "findings": "SELECT " + ", ".join(c.upper() for c in FINDING_COLUMNS)
                + " FROM FINDINGS ORDER BY FINDING, SORT_ORDER",
    "account_monthly": "SELECT ACCOUNT_ID, MONTH || '-01' AS MONTH, MONEY_IN, MONEY_OUT, PENSION_IN, "
                       "HOUSEHOLD_BILLS, INSURANCE, LOAN_PAYMENTS, AVG_DAILY_BALANCE, MIN_BALANCE, "
                       "DAYS_BELOW_ZERO FROM MONTHLY_SUMMARY ORDER BY ACCOUNT_ID, MONTH",
}
COLUMNS = {"account_features": FEATURE_COLUMNS, "findings": FINDING_COLUMNS,
           "account_monthly": MONTHLY_COLUMNS}
# Columns stored as INTEGER in Tiger Data; sources may return them as floats.
INTEGER_COLUMNS = {"account_id", "months", "income_group", "days_below_zero", "owner_age",
                   "people_on_account", "loan_defaulted", "pre_loan_days_below_zero",
                   "sort_order", "accounts"}


def _clean(row, cols):
    return [int(round(v)) if c in INTEGER_COLUMNS and v is not None else v
            for v, c in zip(row, cols)]


def rebuild_in_snowflake(client):
    """Recompute ACCOUNT_FEATURES and FINDINGS inside Snowflake via the SQL API."""
    for name in ("02_features.sql", "03_findings.sql"):
        client.execute((SQL_DIR / name).read_text())


def fetch_snowflake(client, tables):
    return {t: client.execute(SELECTS[t])[1] for t in tables}


def fetch_local(data_dir, tables):
    import sys
    sys.path.insert(0, str(ROOT / "tests"))
    from test_pipeline import build  # same SQL files, run in DuckDB
    con = build(data_dir)
    return {t: [list(r) for r in con.execute(SELECTS[t]).fetchall()] for t in tables}


def ensure_schema(conn):
    with conn.cursor() as cur:
        cur.execute(TIGER_SCHEMA.read_text())
    conn.commit()


def write_tiger(conn, data, source):
    """Replace each table's rows in one transaction, then log the sync."""
    total = 0
    with conn.transaction():
        with conn.cursor() as cur:
            for table, rows in data.items():
                cols = COLUMNS[table]
                cur.execute(f"TRUNCATE {table}")
                with cur.copy(f"COPY {table} ({', '.join(cols)}) FROM STDIN") as copy:
                    for row in rows:
                        copy.write_row(_clean(row, cols))
                total += len(rows)
            cur.execute("INSERT INTO sync_log (source, tables, row_count) VALUES (%s, %s, %s)",
                        (source, ",".join(data), total))
    return total
