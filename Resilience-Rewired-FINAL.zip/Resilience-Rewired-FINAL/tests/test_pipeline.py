"""Run the Snowflake feature and findings SQL in DuckDB and check it against the app.

Usage: python tests/test_pipeline.py /path/to/data
The SQL files are written in portable SQL, so DuckDB runs them unchanged. This proves the
Snowflake logic matches the judges' definitions before it ever touches a Snowflake account.
"""
import json
import sys
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]
SQL = ROOT / "integrations" / "snowflake"
TABLES = ["accounts", "cards", "clients", "dispositions", "districts", "loans",
          "monthly_summary", "standing_orders"]


def build(data_dir):
    con = duckdb.connect()
    for name in TABLES:
        types = {"monthly_summary": "{'month': 'VARCHAR'}",
                 "standing_orders": "{'to_account': 'VARCHAR', 'to_bank': 'VARCHAR'}"}.get(name)
        opts = f", types={types}" if types else ""
        path = str(Path(data_dir) / f"{name}.csv").replace("'", "''")
        con.execute(f"CREATE TABLE {name.upper()} AS SELECT * FROM read_csv('{path}', header=true{opts})")
    for f in ("02_features.sql", "03_findings.sql"):
        con.execute((SQL / f).read_text())
    return con


def main(data_dir):
    con = build(data_dir)
    feats = {r[0]: r for r in con.execute(
        "SELECT ACCOUNT_ID, I, S, F, H, B, P FROM ACCOUNT_FEATURES").fetchall()}
    app = json.loads((ROOT / "dist" / "data" / "accounts.json").read_text())
    assert len(feats) == len(app) == 4500, (len(feats), len(app))
    worst = 0.0
    for key, a in app.items():
        row = feats[int(key)]
        for i, k in enumerate(["I", "S", "F", "H", "B", "P"], start=1):
            worst = max(worst, abs(round(row[i], 2) - a[k]))
    assert worst <= 0.011, f"feature mismatch vs app data: {worst}"
    print(f"ACCOUNT_FEATURES: 4,500 accounts match the app's I, S, F, H, B, P (max diff ${worst:.2f})")

    r = con.execute("SELECT RUNWAY_EI FROM ACCOUNT_FEATURES WHERE ACCOUNT_ID = 21109").fetchone()[0]
    assert round(r, 1) == 4.6, r
    print("Account 21109 runway on EI: 4.6 months (matches the judges' formula)")

    rows = con.execute("SELECT FINDING, GROUP_LABEL, ACCOUNTS, RATE_PCT, MEDIAN_MONEY_IN, "
                       "MEDIAN_BUFFER_MONTHS FROM FINDINGS ORDER BY FINDING, SORT_ORDER").fetchall()
    found = {(f, g): (n, rate, inc, buf) for f, g, n, rate, inc, buf in rows}
    expect = {
        ("income_paradox", "Highest 25% of earners"): 70.3,
        ("income_paradox", "Lowest 25% of earners"): 8.5,
        ("below_zero_before_loan", "Went below $0 before the loan"): 100.0,
        ("ei_cliff", "Run out by month 9"): 53.8,
        ("overall", "Already spend more than they earn"): 26.2,
        ("loan_savings_before", "Under 1 month saved"): 35.2,
        ("loan_payment_share", "Over 50% of income"): 31.9,
    }
    for key, pct in expect.items():
        got = found[key][1]
        assert abs(got - pct) <= 0.6, (key, got, pct)
    print(f"FINDINGS: {len(rows)} rows; headline numbers match the analysis:")
    for (f, g), (n, rate, inc, buf) in found.items():
        print(f"  {f:24s} {g:34s} n={n:5d} rate={rate}%")
    return con


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "data")


def test_health_reports_host(monkeypatch):
    """The app only says it is hosted on Vultr when HOST_PROVIDER says so."""
    import importlib, sys
    sys.path.insert(0, "server")
    monkeypatch.setenv("HOST_PROVIDER", "vultr")
    monkeypatch.setenv("HOST_REGION", "yto")
    app = importlib.import_module("app")
    assert app.health()["host"] == {"provider": "vultr", "region": "yto"}
    monkeypatch.delenv("HOST_PROVIDER")
    monkeypatch.delenv("HOST_REGION")
    assert app.health()["host"] == {"provider": None, "region": None}
