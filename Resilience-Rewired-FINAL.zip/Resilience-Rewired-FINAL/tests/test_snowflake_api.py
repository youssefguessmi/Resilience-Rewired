"""Exercise the SQL API client against a local mock of Snowflake's /api/v2/statements.

Covers: PAT headers, a 202 "still running" response that must be polled, results split
across partitions, and string-to-number conversion. No Snowflake account needed.
"""
import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from snowflake_api import SnowflakeError, SnowflakeSQLAPI  # noqa: E402

ROW_TYPE = [{"name": "ACCOUNT_ID", "type": "fixed", "scale": 0},
            {"name": "RUNWAY_EI", "type": "real"},
            {"name": "INCOME_SOURCE", "type": "text"}]
seen = {"polls": 0, "headers": None, "body": None}


class Mock(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        seen["headers"] = dict(self.headers)
        seen["body"] = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.headers.get("Authorization") != "Bearer test-pat":
            return self._send(401, {"message": "bad token"})
        self._send(202, {"statementHandle": "h1", "message": "Asynchronous execution in progress."})

    def do_GET(self):
        if "partition=1" in self.path:
            return self._send(200, {"data": [["3", "1.5", "pension"]]})
        seen["polls"] += 1
        if seen["polls"] < 2:
            return self._send(202, {"statementHandle": "h1"})
        self._send(200, {"statementHandle": "h1",
                         "resultSetMetaData": {"rowType": ROW_TYPE,
                                               "partitionInfo": [{"rowCount": 2}, {"rowCount": 1}]},
                         "data": [["1", "4.601", "cash deposits"], ["2", None, "transfers"]]})


def main():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Mock)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{server.server_port}"
    client = SnowflakeSQLAPI(token="test-pat", base_url=url, timeout=10)
    cols, rows = client.execute("SELECT ACCOUNT_ID, RUNWAY_EI, INCOME_SOURCE FROM ACCOUNT_FEATURES;")
    assert cols == ["ACCOUNT_ID", "RUNWAY_EI", "INCOME_SOURCE"], cols
    assert rows == [[1, 4.601, "cash deposits"], [2, None, "transfers"], [3, 1.5, "pension"]], rows
    assert seen["headers"]["X-Snowflake-Authorization-Token-Type"] == "PROGRAMMATIC_ACCESS_TOKEN"
    assert not seen["body"]["statement"].endswith(";")
    assert seen["body"]["warehouse"] == "RESILIENCE_WH"
    print("SQL API client: polled 202 responses, joined 2 partitions, typed values, PAT headers OK")

    bad = SnowflakeSQLAPI(token="wrong", base_url=url, timeout=10)
    try:
        bad.execute("SELECT 1")
        raise AssertionError("expected an error")
    except SnowflakeError as err:
        assert "401" in str(err)
    print("SQL API client: a rejected token raises a clear SnowflakeError")
    server.shutdown()


if __name__ == "__main__":
    os.environ.pop("SNOWFLAKE_API_URL", None)
    main()
