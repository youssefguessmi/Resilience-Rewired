"""A stand-in for Snowflake's SQL API, backed by DuckDB running the real SQL files.

  python tests/mock_snowflake.py /path/to/data 8099
  SNOWFLAKE_API_URL=http://127.0.0.1:8099 SNOWFLAKE_PAT=mock python server/app.py

Lets you test /api/refresh and scripts/sync_to_tiger.py --source snowflake end to end
without a Snowflake account. Returns results the way the SQL API does: every value as a
string, a rowType with Snowflake type names, and large results split into partitions.
"""
import json
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_pipeline import build  # noqa: E402

PARTITION_ROWS = 50_000
results = {}
lock = threading.Lock()


def snowflake_type(duck_type):
    t = str(duck_type).upper()
    if any(k in t for k in ("INT", "HUGEINT")):
        return {"type": "fixed", "scale": 0}
    if any(k in t for k in ("DOUBLE", "FLOAT", "DECIMAL", "REAL")):
        return {"type": "real"}
    return {"type": "text"}


def as_text(v):
    if v is None:
        return None
    if isinstance(v, float):
        return repr(v)
    return str(v)


def make_handler(con):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _send(self, code, payload):
            body = json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            if not self.headers.get("Authorization", "").startswith("Bearer "):
                return self._send(401, {"message": "missing token"})
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            with lock:
                cur = con.cursor()
                cur.execute(body["statement"])
                cols = cur.description or []
                rows = cur.fetchall() if cols else []
            handle = str(uuid.uuid4())
            row_type = [{"name": c[0].upper(), **snowflake_type(c[1])} for c in cols]
            data = [[as_text(v) for v in r] for r in rows]
            parts = [data[i:i + PARTITION_ROWS] for i in range(0, len(data), PARTITION_ROWS)] or [[]]
            results[handle] = parts
            self._send(200, {"statementHandle": handle, "data": parts[0],
                             "resultSetMetaData": {"rowType": row_type,
                                                   "partitionInfo": [{"rowCount": len(p)} for p in parts]}})

        def do_GET(self):
            handle = self.path.split("/api/v2/statements/")[1].split("?")[0]
            index = int(self.path.split("partition=")[1]) if "partition=" in self.path else 0
            self._send(200, {"data": results[handle][index]})

    return Handler


def main():
    data_dir, port = sys.argv[1], int(sys.argv[2])
    con = build(data_dir)
    print(f"Mock Snowflake SQL API on http://127.0.0.1:{port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", port), make_handler(con)).serve_forever()


if __name__ == "__main__":
    main()
