# Windows version of deploy.sh. Copies the project to the Vultr server and starts it with Docker Compose.
#
#   .\deploy\vultr\deploy.ps1 root@SERVER_IP
#   .\deploy\vultr\deploy.ps1 root@SERVER_IP yourdomain.com
#
# Needs: a .env in the project root, and the OpenSSH client + tar (both built into Windows 10/11).
param(
  [Parameter(Mandatory = $true)][string]$Target,
  [string]$Domain = ""
)
$ErrorActionPreference = "Continue"

function Check($what) { if ($LASTEXITCODE -ne 0) { throw "$what failed (exit code $LASTEXITCODE)" } }

$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
if (-not (Test-Path (Join-Path $root ".env"))) {
  throw "Missing $root\.env (copy .env.example to .env and fill it in)"
}

Write-Host "Waiting for the server to finish installing Docker (can take 2-3 minutes)..."
$ready = $false
for ($i = 0; $i -lt 30; $i++) {
  ssh -o LogLevel=ERROR -o StrictHostKeyChecking=accept-new -o ConnectTimeout=8 $Target "test -f /opt/resilience/.cloud-init-done" 2>$null
  if ($LASTEXITCODE -eq 0) { $ready = $true; break }
  Start-Sleep -Seconds 10
}
if (-not $ready) { throw "Server not ready. Check the IP, your SSH key, and that cloud-init ran (see README)." }

$archive = Join-Path $env:TEMP "resilience.tar.gz"
tar -czf $archive -C $root --exclude=.git --exclude=__pycache__ --exclude=tests --exclude=.env .
Check "Packing the project"

scp $archive "${Target}:/tmp/resilience.tar.gz"
Check "Uploading the project"
ssh $Target "mkdir -p /opt/resilience && cd /opt/resilience && tar -xzf /tmp/resilience.tar.gz && rm /tmp/resilience.tar.gz"
Check "Unpacking on the server"
scp (Join-Path $root ".env") "${Target}:/opt/resilience/.env"
Check "Uploading .env"

$addr = ":80"
if ($Domain) { $addr = $Domain }
ssh $Target "cd /opt/resilience/deploy/vultr && SITE_ADDRESS='$addr' docker compose up -d --build"
Check "Starting the containers"

$hostName = $Target.Split("@")[-1]
$url = "http://$hostName"
if ($Domain) { $url = "https://$Domain" }
Write-Host "Deployed. Checking health..."
Start-Sleep -Seconds 8
try {
  (Invoke-RestMethod "$url/api/health") | ConvertTo-Json -Depth 5
  Write-Host "Open $url"
} catch {
  Write-Host "Server started but the health check did not answer yet. Wait a minute, then open $url"
}
